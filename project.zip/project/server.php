<html>
<head>
<meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
	</head>
	<body>
    <div class="page-header">
	<h1>Hi,<br> satya minz </br>  Welcome to the page.</h1>
	</div>
	</body>
</html>